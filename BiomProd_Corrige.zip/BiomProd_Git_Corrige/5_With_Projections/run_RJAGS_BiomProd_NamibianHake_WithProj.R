# ---------------------------------------------------------------
# JAGS code for Dynamic Biomass Production Model
# 5 - Model with Catches and AI and 5 years projection 
# ---------------------------------------------------------------


rm(list = ls())

# ---------------------------------------------------------------

# Check the path to JAGS.exe

# Optionnel if rjags can not connect directly to the JAGS.exe installed on your computer
# You will see that in the information message after loading the rjags library
# CAUTION : the path C:\\ is to be adapted to redirect where your JAGS.exe is installed
# the name JAGS-4.2.0 should also be changed if another version of JAGS is installed on your computer

# Sys.setenv(JAGS_HOME = "C:\\prog_td\\JAGS\\JAGS-4.2.0\\")

# ---------------------------------------------------------------

library(rjags)
library(coda)
library(MASS)


# Load the model
# ----------------------------------------

# Load the model, written in a .txt file

source("5_With_Projections/model_BiomProd_WithScenario_JAGS.txt")

# Write the model specification into a text file with name "model.txt", to be found by JAGS
# The file "model.txt" will be used by functions "jags.model" and "coda.sample" (see below)

cat(model_JAGS, file="model.txt")


# Load and format data
# -----------------------------------------

# load data

data <- read.table(file = "data/data_BiomProd.txt", header = TRUE, sep = "") 

B_e <- seq(from = 0, to = 1500, by = 50)
n_equi <- length(B_e)

n <- length(data$Year)
n_proj <- 5
n_obs <- n-n_proj
Year <- data$Year


# Format data as a list to be read in JAGS

data <- list("I_obs" = data$I, "C_obs" = data$C, "n" = n, "n_obs" = n_obs, "n_proj" = n_proj,
		 "B_e" = B_e, "n_equi" = n_equi)

# save(data, file = "data.Rdata")



# MCMC options
# ----------------------------------------------------------------------

n.chains = 3

# Adapt the MCMC samplers with n.adapt iterations

n.adapt = 10000

# Iteration after adapting

n.burnin <- 1000
n.stored <- 1000
n.thin <- 10
n.iter <- n.stored*n.thin

# MANAGING NUMBER of ITERATIONS
# (works for both para = T and para = F)
# total number of REALIZED iterations = n.iter
# total number of STORED iterations = n.iter/n.thin



# Run the model to save MCMC results
# ---------------------------------------------------------------------

# Variable to store

monitor <- c( "B", "h", "D",
		"r", "r_p", "K", "K_p", "q", "sigma2p",
		"C_MSY", "C_MSY_p", "B_MSY", "h_MSY", 
		"risk", "Over_C","Over_h",
		"C_e",
		"I_pred", "C_pred")

# Compile the model, create a model object with the name "model.compiled.jags" and adapt the MCMC samplers
# with n.adapt iterations

print("adapting phase")
model.compiled.jags <- jags.model(file = "model.txt", data=data, n.chain=n.chains, n.adapt=n.adapt)

# Iteration after adapting

# Start to compute CPU time
ptm <- proc.time()

# Burnin period (not stored)

print("burn-in")
update(model.compiled.jags, n.iter=n.burnin)

# Store mcmc samples

print("mcmc stored for results")
mcmc <- coda.samples(model=model.compiled.jags,variable.names=monitor,n.iter=n.iter,thin=n.thin)

time.to.run.mcmc <- proc.time() - ptm
print(time.to.run.mcmc)

# ----------------------------------------------------------------------------------------------


# Run the model to compute DIC
# ---------------------------------------------------------------------

# Start from a compiled model that has already been updated

dic.pD <- dic.samples(model.compiled.jags, n.iter, "pD") 
dic.pD		# Deviance Information Criterion

# Alternative penalization of the Deviance
# dic.popt <- dic.samples(model.compiled.jags, n.iter, "popt")
# dic.popt
# -----------------------------------------------------------------------



# --------------------------------------------
# Work with mcmc.list
# --------------------------------------------

# "mcmc" is an object of the class "mcmc.list" (see package library(coda)
# to explore, plot ... mcmc objects

is(mcmc)


# Names of the variables stored in the mcmc list

var <- varnames(mcmc)
var

